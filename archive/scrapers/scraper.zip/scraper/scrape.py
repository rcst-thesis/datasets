import pdfplumber
import re
import json
import csv

PDF_PATH = "9780824881993.pdf"

hil_words = []
en_definitions = []

print("Reading PDF...")

with pdfplumber.open(PDF_PATH) as pdf:
    full_text = ""
    for i in range(28, len(pdf.pages)):
        page = pdf.pages[i]
        text = page.extract_text()
        if text:
            full_text += text + "\n"

print(f"Extracted {len(full_text)} characters. Parsing entries...")

lines = full_text.split("\n")

current_word = None
current_def = []

def clean_definition(raw):
    # Remove affix patterns like /mag-,-un/
    cleaned = re.sub(r'/[^/]+/', '', raw)
    # Remove example sentences — anything that starts with a capital Hiligaynon name or sentence
    # Stop at first sentence that looks like an example (contains proper noun + verb pattern)
    cleaned = re.sub(r'\s*[A-Z][a-záéíóú]+[^.]*\..*', '', cleaned)
    # Remove page numbers
    cleaned = re.sub(r'\b\d+\b', '', cleaned)
    # Remove extra POS tags that sneak in mid-definition
    cleaned = re.sub(r'\b(v|n|adj|adv|con|pr|pt|prep|num|interj)\b', '', cleaned)
    # Remove leftover dashes and clean whitespace
    cleaned = re.sub(r'\s+', ' ', cleaned)
    cleaned = cleaned.strip(" .,;:-")
    return cleaned

for line in lines:
    line = line.strip()
    if not line:
        continue

    # Skip headers
    if line in ["HILIGAYNON DICTIONARY", "A","B","K","D","E","F","G","H","I","L","M","N","NG","O","P","R","S","T","U","W","Y"]:
        continue

    # Match new dictionary entry
    new_entry = re.match(
        r'^([a-záéíóúàèìòùâêîôûñ\'\-]+(?:\'[a-z]+)?)\s+(v|n|adj|adv|con|pr|pt|prep|num|interj|abbr|affix)\b(.*)$',
        line, re.IGNORECASE
    )

    if new_entry:
        # Save previous entry
        if current_word and current_def:
            raw_def = " ".join(current_def).strip()
            en_part = clean_definition(raw_def)
            if en_part and len(en_part) > 1:
                hil_words.append(current_word)
                en_definitions.append(en_part)

        # Start new entry
        current_word = new_entry.group(1).strip()
        rest = new_entry.group(3).strip()
        current_def = [rest] if rest else []

    else:
        if current_word:
            current_def.append(line)

# Save last entry
if current_word and current_def:
    raw_def = " ".join(current_def).strip()
    en_part = clean_definition(raw_def)
    if en_part and len(en_part) > 1:
        hil_words.append(current_word)
        en_definitions.append(en_part)

# Build data
data = [
    {"hiligaynon": hil, "english": en}
    for hil, en in zip(hil_words, en_definitions)
]

# Save train.hil
with open("train.hil", "w", encoding="utf-8") as f:
    for word in hil_words:
        f.write(word + "\n")

# Save train.en
with open("train.en", "w", encoding="utf-8") as f:
    for defn in en_definitions:
        f.write(defn + "\n")

# Save JSON
with open("dictionary.json", "w", encoding="utf-8") as f:
    json.dump(data, f, ensure_ascii=False, indent=2)

# Save CSV
with open("dictionary.csv", "w", encoding="utf-8", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=["hiligaynon", "english"])
    writer.writeheader()
    writer.writerows(data)

# Save TXT
with open("dictionary.txt", "w", encoding="utf-8") as f:
    for hil, en in zip(hil_words, en_definitions):
        f.write(f"{hil} - {en}\n")

# Preview
print("\n--- PREVIEW ---")
for i in range(min(15, len(hil_words))):
    print(f"{hil_words[i]} - {en_definitions[i]}")

print(f"\nDone! {len(hil_words)} entries saved!")
print("Files: train.hil | train.en | dictionary.json | dictionary.csv | dictionary.txt")