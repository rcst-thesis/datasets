import json
import csv
import re
import pdfplumber
from collections import defaultdict

PDF_PATH = r"C:\Users\User\Desktop\scraper_2\English-Hiligaynon-Dictionary.pdf"
JSON_OUT = r"C:\Users\User\Desktop\scraper_2\hiligaynon_english_dictionary.json"
CSV_OUT  = r"C:\Users\User\Desktop\scraper_2\hiligaynon_english_dictionary.csv"

# Column boundary: left col x < SPLIT, right col x >= SPLIT
COLUMN_SPLIT = 240   # midpoint between ~155 and ~303

def extract_column_lines(pdf_path):
    """
    Extract lines from each page respecting two-column layout.
    Returns a list of text lines in reading order (left col top→bottom, then right col).
    """
    all_lines = []

    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            words = page.extract_words(keep_blank_chars=False, x_tolerance=3, y_tolerance=3)

            # Separate words into left and right columns
            left_words  = [w for w in words if w['x0'] < COLUMN_SPLIT]
            right_words = [w for w in words if w['x0'] >= COLUMN_SPLIT]

            # Group words into lines by their 'top' coordinate (round to nearest 2px)
            def group_into_lines(word_list):
                buckets = defaultdict(list)
                for w in word_list:
                    bucket_key = round(w['top'] / 2) * 2
                    buckets[bucket_key].append(w)
                lines = []
                for key in sorted(buckets.keys()):
                    row_words = sorted(buckets[key], key=lambda w: w['x0'])
                    line_text = " ".join(w['text'] for w in row_words)
                    lines.append(line_text)
                return lines

            left_lines  = group_into_lines(left_words)
            right_lines = group_into_lines(right_words)

            all_lines.extend(left_lines)
            all_lines.extend(right_lines)

    return all_lines


def parse_entry(line):
    """
    Parse a single dictionary line into (english, pos, hiligaynon).
    Returns None if line doesn't match expected format.

    Formats:
      abandon pabayaan , abandonar
      aback ( to be taken aback) palak
      able ( adjective) makasangkul
      able to ( can do it) sarang , ako
    """
    line = line.strip()
    if not line or len(line) < 4:
        return None

    # Skip headers / page numbers / section dividers
    if re.match(r'^English\s*[–\-]', line, re.IGNORECASE):
        return None
    if re.match(r'^\d{1,3}$', line):
        return None
    if line == ':':
        return None

    # --- Main regex ---
    # english_word(s)  [( note )]  hiligaynon_translation
    #
    # English part: one or more capitalized/lowercase words, hyphens, apostrophes
    # Note part (optional): ( ... )
    # Hiligaynon part: must start with a lowercase letter and contain at least one Hiligaynon-ish word
    #
    # Key constraint: Hiligaynon translations are lowercase and often contain
    # commas separating synonyms.  They do NOT start with '(' directly.

    pattern = re.compile(
        r'^'
        r'([A-Za-z][A-Za-z0-9\s\-\'\./]*?)'   # English word(s) — non-greedy
        r'(?:\s*\(([^)]*)\))?'                  # optional ( note )
        r'\s+'
        r'([a-z].*)$'                            # Hiligaynon — starts lowercase
    )

    m = pattern.match(line)
    if not m:
        return None

    english = m.group(1).strip()
    pos     = (m.group(2) or "").strip()
    hil     = m.group(3).strip()

    # Sanity checks
    if not english or len(english) < 1:
        return None
    # Hiligaynon part must contain at least one actual word char
    if not re.search(r'[a-z]{2,}', hil):
        return None
    # English part should not itself look like a Hiligaynon word (all lowercase + no spaces)
    # i.e. if english has no uppercase and no spaces, it's probably just a hiligaynon word, skip
    if english == english.lower() and ' ' not in english and len(english) > 1:
        # Could still be valid (e.g. "abandon") — allow if first char was originally uppercase context
        pass  # we'll keep it

    return {
        "english": english,
        "pos": pos,
        "hiligaynon": hil
    }


def deduplicate(entries):
    """Keep first occurrence of each (english, pos) pair."""
    seen = set()
    result = []
    for e in entries:
        key = (e['english'].lower(), e['pos'].lower())
        if key not in seen:
            seen.add(key)
            result.append(e)
    return result


def main():
    print("Extracting lines from PDF (column-aware)...")
    lines = extract_column_lines(PDF_PATH)
    print(f"  Total lines extracted: {len(lines)}")

    print("Parsing entries...")
    entries = []
    for line in lines:
        entry = parse_entry(line)
        if entry:
            entries.append(entry)

    entries = deduplicate(entries)
    print(f"  Unique entries found: {len(entries)}")

    # Show sample
    print("\nSample entries (first 20):")
    for e in entries[:20]:
        print(f"  [{e['english']:30s}] ({e['pos']:20s}) => {e['hiligaynon']}")

    # Save JSON
    with open(JSON_OUT, 'w', encoding='utf-8') as f:
        json.dump(entries, f, ensure_ascii=False, indent=2)
    print(f"\nSaved JSON: {JSON_OUT}  ({len(entries)} entries)")

    # Save CSV
    with open(CSV_OUT, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=['english', 'pos', 'hiligaynon'])
        writer.writeheader()
        writer.writerows(entries)
    print(f"Saved CSV:  {CSV_OUT}  ({len(entries)} entries)")

    # Stats
    with_pos = [e for e in entries if e['pos']]
    print(f"\nEntries with POS/note: {len(with_pos)}")
    print(f"Entries without POS:   {len(entries) - len(with_pos)}")


if __name__ == "__main__":
    main()